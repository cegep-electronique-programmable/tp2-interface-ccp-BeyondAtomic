
#include "mcc_generated_files/mcc.h"

#define RAPPORT_MIN 3.5         // Limite Basse pour le rapport cyclique
#define RAPPORT_MAX 11.5        // Limite haute pour le rapport cyclique
#define POSITION_CENTRE 7.0     // Rapport cyclique pour 0 degr�
#define POSITION_DROITE 11.0    // Rapport cyclique pour +90 degr�
#define POSITION_GAUCHE 5.0     // Rapport cyclique pour -90 degr�

double vitesse = 7.0;           // valeur initial de la vitesse

void    ajusterVitesse(double rapport); 
int     trouver_CCPR (double rapport); 
void    tournerGauche();
void    tournerDroite();
void    centrer();
int rxdata = 0;

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    

    

    
    while (1)
    {
        if(EUSART1_is_rx_ready)
        {

            char Lettre = EUSART1_Read();

            switch(Lettre)
            {
                case'U':
                    printf("\r\nU\r\n");
                    tournerGauche();
                    break;
                    
                case'L':
                    printf("\r\nL\r\n");
                    tournerDroite();
                    break;
            }
        }
    }
    while(1){}
}

int trouver_CCPR (double rapport)                                    
{
    
    if(rapport < RAPPORT_MIN)
    {
        rapport = RAPPORT_MIN;
    }
    else if(rapport > RAPPORT_MAX)
    {
        rapport = RAPPORT_MAX;
    }
    
    double ccpr_val = (((rapport / 100)*19.968)/32.768)*1023;          
    
    return (int) ccpr_val;
}

void ajusterVitesse(double rapport)                                    
{
    int ccpr_val = trouver_CCPR(rapport);
    PWM2_LoadDutyValue(ccpr_val);
    printf("\r\n%d\r\n",ccpr_val);
}

// fonction pour faire tourner -90� (d�barrer)
void tournerGauche()                                                  
{
    rxdata = rxdata - 90;
    
    printf("\r\n%d\r\n",rxdata);
    
    vitesse = POSITION_GAUCHE;
    
    if (RAPPORT_MIN)
    {
        POSITION_GAUCHE;
    }

    ajusterVitesse(vitesse);
     
}

// fonction pour faire tourner 90� (barrer)
void tournerDroite()                                                  
{
    
    rxdata = rxdata + 90;
    
    printf("\r\n%d\r\n",rxdata);
    
    vitesse = POSITION_DROITE;
    
    if (RAPPORT_MAX)
    {
        POSITION_DROITE;
    }

    ajusterVitesse(vitesse);
    
}

void centrer()                                                          
{
    vitesse = POSITION_CENTRE;
    ajusterVitesse(vitesse);
}