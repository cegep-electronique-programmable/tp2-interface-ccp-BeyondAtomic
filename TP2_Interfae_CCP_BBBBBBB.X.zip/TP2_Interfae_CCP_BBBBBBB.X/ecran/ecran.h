/*
* ecran.h
* Contient toutes les fonctions pour interagir avec l'ecran modele
* NHD-0420D3Z-FL-GBW
*
* Auteur : Philippe Lefebvre
*/

#ifndef ECRAN_H
#define ECRAN_H

/***********Includes************/


/************Defines************/


/*********Declarations**********/
/*
* Fonction : ecranAllume
* Description : Envoie la commande pour allumer l'ecran
*
* Params : Aucun
* 
* Retour : Aucun
*/
void ecranAllume(void);

/*
* Fonction : ecranAllume
* Description : allume l'ecran
*
* Params : Aucun
* 
* Retour : Aucun
*/
void ecranEteint(void);

/*
* Fonction : ecranEteint
* Description : Envoie la commande pour eteindre l'ecran
*
* Params : Aucun
* 
* Retour : Aucun
*/
void curseurPosition(int position);

/*
* Fonction : curseurPosition
* Description : bouge le curseur dans la bonne place
*
* Params : Aucun
* 
* Retour : Aucun
*/
void videEcran(void);

/*
* Fonction : videEcran
* Description : vide l'ecran 
*
* Params : Aucun
* 
* Retour : Aucun
*/
void ecrit(char charactere);

/*
* Fonction : ecrire
* Description : ecrit le charactere
*
* Params : Aucun
* 
* Retour : charactere
*/
#endif