/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F25K80
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"

#define VCC 5.0
uint16_t gDuree = 0;
uint16_t lastCapture = 0;
uint16_t risingEdge;
uint16_t fallingEdge;
uint16_t nextRisingEdge;
uint16_t highTime;
uint16_t period;
float fluxDensity;
char polarity;


void myCCP2Capture_ISR(uint16_t capturedValue);



void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    while (1)
    {
        
        fluxDensity = readFluxDensity();
        
        if(fluxDensity > 0)
        {
            polarity = 'N';
        }
        else
        {
            polarity = 'S';
        }
        
        printf("\r\nHigh Time: %d ms\r\n",highTime);
        printf("\r\nPeriod: %d ms\r\n",period);
        printf("\r\nFlux Density: %d mt\r\n",fluxDensity); 
        printf("\r\nPolarity: %d\r\n",polarity);  
    }
}

float readFluxDensity()
{
    uint16_t adcValue = ADC_GetConversion(0);
    float voltage = adcValue * (VCC / 1023.0);
    return (voltage - (VCC / 2)) / 0.02;
}

void myCCP2Capture_ISR(uint16_t capturedValue, char edgeType)
{
    if (edgeType == /*rising*/ )
    {
        risingEdge = capturedValue;
    }
    else if (edgeType == /*falling*/ )
    {
        fallingEdge = capturedValue;
        highTime = fallingEdge - risingEdge;
    }
    else if (edgeType == /*next rising*/ )
    {
        nextRisingEdge = capturedValue;
        period = nextRisingEdge - risingEdge;
    }
}
